# -*- coding: utf-8 -*-

__all__ = ['classification_MINST']
# deprecated to keep older scripts who import this from breaking

